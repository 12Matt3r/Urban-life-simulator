// systems/db.js
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

var __ENV__ = (window && window.__ENV__) ? window.__ENV__ : {};
const url = __ENV__.SUPABASE_URL;
const key = __ENV__.SUPABASE_ANON_KEY;

export const supabase = (url && key) ? createClient(url, key) : null;

export async function ensureAuth() {
  if (!supabase) return null;
  const sess = await supabase.auth.getSession();
  const session = (sess && sess.data) ? sess.data.session : null;
  if (session && session.user) return session.user;
  try {
    const res = await supabase.auth.signInAnonymously();
    if (res && res.data && res.data.user) return res.data.user;
    return null;
  } catch (e) { return null; }
}

export async function cloudSave(slot, data) {
  if (!supabase) throw new Error("Supabase not configured");
  const user = await ensureAuth();
  if (!user) throw new Error("No auth user");
  const payload = { user_id: user.id, slot: slot, data: data, updated_at: new Date().toISOString() };
  const up = await supabase.from("saves").upsert(payload, { onConflict: "user_id,slot" });
  if (up.error) throw up.error;
}

export async function cloudLoad(slot) {
  if (!supabase) throw new Error("Supabase not configured");
  const user = await ensureAuth();
  if (!user) throw new Error("No auth user");
  const q = await supabase.from("saves")
    .select("data, updated_at").eq("user_id", user.id).eq("slot", slot).maybeSingle();
  if (q.error) throw q.error;
  return q.data || null;
}

export async function listStations() {
  if (!supabase) return [];
  const q = await supabase.from("stations").select("*").order("name");
  if (q.error) throw q.error;
  return q.data || [];
}

export async function uploadTrackToStation(opts) {
  if (!supabase) throw new Error("Supabase not configured");
  const user = await ensureAuth();
  if (!user) throw new Error("No auth user");

  var file = opts.file;
  var stationId = opts.stationId;
  var title = opts.title;
  var artist = opts.artist;

  var parts = String(file.name || '').split('.');
  var ext = parts.length ? parts[parts.length - 1].toLowerCase() : 'mp3';
  var objectPath = user.id + "/" + Date.now() + "_" + sanitize(title) + "." + ext;

  const up = await supabase.storage.from("radio").upload(objectPath, file, { cacheControl: "3600", upsert: false });
  if (up.error) throw up.error;

  const pubRes = supabase.storage.from("radio").getPublicUrl(objectPath);
  const publicUrl = (pubRes && pubRes.data) ? pubRes.data.publicUrl : null;

  const ins = await supabase.from("tracks").insert({
    station_id: stationId, title: title, artist: artist, file_path: objectPath, created_by: user.id
  }).select("id").single();
  if (ins.error) throw ins.error;

  return { trackId: ins.data.id, url: publicUrl };
}

export async function getLatestTrackPublicUrl(stationId) {
  if (!supabase) return null;
  const q = await supabase
    .from('tracks')
    .select('file_path')
    .eq('station_id', stationId)
    .order('created_at', { ascending: false })
    .limit(1);
  if (q.error) { console.warn('list tracks error', q.error.message); return null; }
  const filePath = q.data && q.data[0] ? q.data[0].file_path : null;
  if (!filePath) return null;
  const pub = supabase.storage.from('radio').getPublicUrl(filePath);
  return (pub && pub.data) ? pub.data.publicUrl : null;
}

export function resolveExternalAudio(url) {
  var u = String(url || '').trim();
  if (!u) return null;
  if (/\.(mp3|ogg|wav|m4a)(\?|#|$)/i.test(u)) return u;
  if (/youtu\.be\/|youtube\.com\/watch\?v=/.test(u)) {
    var id = (u.match(/youtu\.be\/([^?&#]+)/) || [])[1] || (u.match(/[?&]v=([^&#]+)/) || [])[1] || '';
    if (!id) return null;
    return "iframe:https://www.youtube.com/embed/" + id + "?autoplay=1&rel=0";
  }
  if (/soundcloud\.com\//.test(u)) {
    var enc = encodeURIComponent(u);
    return "iframe:https://w.soundcloud.com/player/?url=" + enc + "&auto_play=true";
  }
  return u;
}

function sanitize(s){ return String(s).toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,""); }
