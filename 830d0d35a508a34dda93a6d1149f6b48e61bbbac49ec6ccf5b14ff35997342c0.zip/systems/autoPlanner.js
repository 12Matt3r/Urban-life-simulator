// systems/autoPlanner.js  (ES-safe: no optional chaining/nullish coalescing)

var state = { running: false, tick: 0 };
var timer = null;
var bus = null;

// Helper: get available decisions without optional chaining
function _getAvailableDecisions() {
  if (!window.Life || !window.Life.getAvailableDecisions) return [];
  try { return window.Life.getAvailableDecisions(); } catch (e) { return []; }
}

// Helper: apply decision safely
function _applyDecision(decision) {
  if (!window.Life || !window.Life.applyDecision) return;
  try { window.Life.applyDecision(decision); } catch (e) {}
}

// Main loop
function loop(singleStep) {
  if (!state.running) return;

  var decisions = _getAvailableDecisions();
  if (decisions && decisions.length > 0) {
    var idx = Math.floor(Math.random() * decisions.length);
    var choice = decisions[idx];
    _applyDecision(choice);
    if (bus && bus.publish) bus.publish('simlog.push', { text: 'Auto-Play chose: "' + (choice.label || choice.text || 'unknown') + '"' });
  } else {
    if (bus && bus.publish) bus.publish('simlog.push', { text: 'Auto-Play: No decisions available.' });
  }

  state.tick++;
  if (!singleStep) {
    timer = setTimeout(loop, 1000);
  } else {
    state.running = false;
  }
}

export function start(config, eventBus) {
  bus = eventBus;
  state = { running: true, tick: 0 };
  // Optional: respect speed/risk/aggression from config if you later add logic here
  loop(false);
}

export function stop() {
  state.running = false;
  if (timer) { clearTimeout(timer); timer = null; }
}

export function step() {
  if (!state.running) { state.running = true; loop(true); }
}
