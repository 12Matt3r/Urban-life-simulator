// systems/narrativeEngine.js  (ES-safe: no optional chaining/nullish coalescing)
var NARRATOR_IFRAME_ORIGIN = "https://websim.com";
function narratorFrameEl() { return document.getElementById("websim-narrator"); }

function askWebSimNarrator(payload) {
  var frame = narratorFrameEl();
  if (!frame || !frame.contentWindow) throw new Error("WebSim narrator iframe not found");
  frame.contentWindow.postMessage({ type: "requestEvent", payload: payload }, NARRATOR_IFRAME_ORIGIN);
}

function nextEventViaWebSim(ctx, timeoutMs) {
  timeoutMs = typeof timeoutMs === 'number' ? timeoutMs : 20000;
  return new Promise(function (resolve, reject) {
    var done = false;
    function onMsg(ev) {
      if (ev.origin !== NARRATOR_IFRAME_ORIGIN) return;
      var msg = ev.data || {};
      if (msg.type === "narration") {
        cleanup(); done = true; return resolve(msg.payload);
      }
      if (msg.type === "narration_error") {
        cleanup(); done = true; return reject(new Error(msg.error));
      }
    }
    function cleanup() { window.removeEventListener("message", onMsg); }
    window.addEventListener("message", onMsg);
    try {
      askWebSimNarrator({
        character: ctx && ctx.character,
        history: (ctx && ctx.history ? ctx.history.slice(-10) : []),
        lastEvent: ctx && ctx.lastEvent ? ctx.lastEvent : null,
        rails: { maxDecisions: Math.max(2, Math.min(4, (ctx && ctx.rails && typeof ctx.rails.maxDecisions === 'number') ? ctx.rails.maxDecisions : 3)) }
      });
    } catch (e) {
      cleanup(); return reject(e);
    }
    setTimeout(function () { if (!done) { cleanup(); reject(new Error("websim_timeout")); } }, timeoutMs);
  });
}

function localMockNext() {
  return Promise.resolve({
    id: "fallback_mock",
    title: "Quiet Night",
    description: "The city hums like a live wire; nothing moves unless you make it. What do you do now?",
    decisions: [
      { id: "d1", text: "Walk the block", risk: 20, aggression: 10, resourceRisk: 5, heatSpike: 0, goalAlignment: 40, tags: ["patrol"] },
      { id: "d2", text: "Call a contact for work", risk: 35, aggression: 10, resourceRisk: 10, heatSpike: 5, goalAlignment: 55, tags: ["job","contact"] }
    ],
    imagePrompt: "empty street at night"
  });
}

export function createNarrativeEngine(opts) {
  opts = opts || {};
  var mode = opts.mode || "websim";
  return {
    mode: mode,
    nextEvent: function (ctx) {
      if (mode === "websim") {
        return nextEventViaWebSim(ctx).catch(function () {
          console.warn("WebSim failed → local mock fallback");
          return localMockNext(ctx);
        });
      }
      return localMockNext(ctx);
    }
  };
}
